export default[

    {
        path: "/M2/eng/multiply1/Index",
        name: "eng-multiply1-index",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply1/EngMultiply1Index.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply1/multiply101",
        name: "eng-multiply101",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply1/EngMultiply101.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply1/multiply102",
        name: "eng-multiply102",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply1/EngMultiply102.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply1/multiply103",
        name: "eng-multiply103",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply1/EngMultiply103.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply1/multiply104",
        name: "eng-multiply104",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply1/EngMultiply104.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply1/multiply105",
        name: "eng-multiply105",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply1/EngMultiply105.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply1/multiply106",
        name: "eng-multiply106",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply1/EngMultiply106.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply1/multiply107",
        name: "eng-multiply107",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply1/EngMultiply107.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply1/multiply108B",
        name: "eng-multiply108B",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply1/EngMultiply108B.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply1/multiply108",
        name: "eng-multiply108",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply1/EngMultiply108.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply1/multiply109",
        name: "eng-multiply109",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply1/EngMultiply109.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply1/multiply110",
        name: "eng-multiply110",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply1/EngMultiply110.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply1/multiply111",
        name: "eng-multiply111",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply1/EngMultiply111.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply1/multiply112",
        name: "eng-multiply112",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply1/EngMultiply112.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply1/multiply113",
        name: "eng-multiply113",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply1/EngMultiply113.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply1/multiply114",
        name: "eng-multiply114",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply1/EngMultiply114.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply1/multiply115",
        name: "eng-multiply115",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply1/EngMultiply115.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply1/multiply116",
        name: "eng-multiply116",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply1/EngMultiply116.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply1/multiply117",
        name: "eng-multiply117",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply1/EngMultiply117.vue"
          );
        },
    },
];