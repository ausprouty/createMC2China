<script>
import { useAddNote, useShowNotes} from "@/assets/javascript/notes.js"
import { useFindSummaries, useFindCollapsible, usePopUp} from "@/assets/javascript/revealText.js"
import { useGoToPageAndSetReturn, usePageGoBack } from "@/assets/javascript/travel.js"
import { useRevealMedia } from "@/assets/javascript/revealMedia.js"
import Footer from '@/components/FooterGlobal.vue'

export default {
  components: {
    Footer
  },

  methods:{
    addNote(){
      useAddNote(this.$route.name)
    },
    goToPageAndSetReturn(goto){
      localStorage.setItem("returnpage", this.$route.name);
      this.$router.push({
        path: goto,
      })
    },
    pageGoBack(){
      if (localStorage.getItem("returnpage")) {
        returnto = localStorage.getItem("returnpage");
        localStorage.removeItem("returnpage");
        vuePush(returnto)
      }
    },
    popUp(verse){
      usePopUp(verse)
    },
    vuePush(id){
      this.$router.push({
        name: id,
      })
    },
  },
  mounted() {
    useFindSummaries()
    useFindCollapsible()
    let route_path = this.$route.path
    let last = route_path.lastIndexOf('/')
    let series_path = route_path.substr(0, last)
    console.log (series_path)
    useRevealMedia(series_path)
    useShowNotes(this.$route.name)
  },
}
</script>
<template>
  <div>
<div class="page_content ltr">
<div class="block ltr">
                        <div class="chapter_number ltr"><h1>52.</h1></div>
                        <div class="chapter_title ltr"><h1>Jesus' Faithfulness to His Promise</h1></div>
                    </div>
<div id="showVideoOptions"></div>


  <div class="lesson"><img class="lesson-icon" src="@/assets/images/standard/look-back.png" />
<div class="lesson-subtitle"><span class="back">LOOKING BACK</span></div>
</div>

<!-- begin default revealSummary -->
<div id="Summary0" class="summary"><h2 class="back">+ Praise</h2></div>
<div class="collapsed" id ="Text0">
<!-- end default revealSummary -->
<p class="back"><em>Read a scripture and sing worship songs.</em></p>

<p class="back">(Optional) Jesus Christ is Lord, to the glory of God the Father. He wants all men to be saved and to come to the knowledge of the truth. For there is one God and one mediator also between God and man, the man Jesus Christ, who gave himself as a ransom for all. (Philippians 2:11b; 1 Timothy 2:4-6a)</p>

</div>

<h2 class="back">Caring for each other</h2>

<p><em>Minister to one another&rsquo;s needs in prayer, biblical counsel and encouragement. </em></p>

<ul>
	<li>Ask each person to tell one highlight and explain one challenge they experienced this week.</li>
	<li>Ask, &ldquo;What do you want Jesus to do for you this week?&rdquo; Pray for each other&rsquo;s needs.</li>
</ul>

<h2 class="back">Celebrating&nbsp; Faithfulness</h2>

<p>Encourage loving accountability to obey Jesus</p>

<ul class="back">
	<li>Ask, &ldquo;What happened as you trusted God with your goals and I will statements?&rdquo;</li>
</ul>

<!-- begin default revealSummary -->
<div id="Summary1" class="summary"><h2 class="back">+ Motivation and Encouragement</h2></div>
<div class="collapsed" id ="Text1">
<!-- end default revealSummary -->
<p class="back"><em>Choose a way to cast vision for who they can become in Christ or what God can do through them by:</em></p>

<ul>
	<li class="back">a scripture that reminds them of the Father&rsquo;s Heart and of the end vision.</li>
	<li class="back">reflecting on the changes in their life since they started following Christ</li>
	<li class="back">reminding them of what God wants to do through them</li>
</ul>

<p class="back"><em>Share BIG vision &ldquo;A church for every village and community, and the gospel for every person.&rdquo;</em></p>

</div>

<div class="lesson"><img class="lesson-icon" src="@/assets/images/standard/look-up.png" />
<div class="lesson-subtitle"><span class="up">LOOKING UP</span></div>
</div>

<h2 class="up">Context</h2>

<ul>
	<li class="up">Ask the group to tell the story from last week.</li>
</ul>

<h2 class="up">Read</h2>

<ul>
	<li class="up">Read or watch Acts 27:27-44 two times as others listen.</li>
</ul>

<button id="Button0" type="button" class="collapsible bible">Read Acts 27:27-44</button><div class="collapsed" id ="Text0">
<!-- begin bible -->

<h3>The Shipwreck</h3>

<p><sup class="versenum">27&nbsp;</sup>On the fourteenth night we were still being driven across the Adriatic Sea, when about midnight the sailors sensed they were approaching land.<sup class="versenum">28&nbsp;</sup>They took soundings and found that the water was a hundred and twenty feet deep. A short time later they took soundings again and found it was ninety feet deep.<sup class="versenum">29&nbsp;</sup>Fearing that we would be dashed against the rocks, they dropped four anchors from the stern and prayed for daylight.<sup class="versenum">30&nbsp;</sup>In an attempt to escape from the ship, the sailors let the lifeboat down into the sea, pretending they were going to lower some anchors from the bow.<sup class="versenum">31&nbsp;</sup>Then Paul said to the centurion and the soldiers, &ldquo;Unless these men stay with the ship, you cannot be saved.&rdquo;<sup class="versenum">32&nbsp;</sup>So the soldiers cut the ropes that held the lifeboat and let it drift away.</p>

<p><sup class="versenum">33&nbsp;</sup>Just before dawn Paul urged them all to eat. &ldquo;For the last fourteen days,&rdquo; he said, &ldquo;you have been in constant suspense and have gone without food&mdash;you haven&rsquo;t eaten anything.<sup class="versenum">34&nbsp;</sup>Now I urge you to take some food. You need it to survive. Not one of you will lose a single hair from his head.&rdquo;<sup class="versenum">35&nbsp;</sup>After he said this, he took some bread and gave thanks to God in front of them all. Then he broke it and began to eat.<sup class="versenum">36&nbsp;</sup>They were all encouraged and ate some food themselves.<sup class="versenum">37&nbsp;</sup>Altogether there were 276 of us on board.<sup class="versenum">38&nbsp;</sup>When they had eaten as much as they wanted, they lightened the ship by throwing the grain into the sea.</p>

<p><sup class="versenum">39&nbsp;</sup>When daylight came, they did not recognize the land, but they saw a bay with a sandy beach, where they decided to run the ship aground if they could.<sup class="versenum">40&nbsp;</sup>Cutting loose the anchors, they left them in the sea and at the same time untied the ropes that held the rudders. Then they hoisted the foresail to the wind and made for the beach.<sup class="versenum">41&nbsp;</sup>But the ship struck a sandbar and ran aground. The bow stuck fast and would not move, and the stern was broken to pieces by the pounding of the surf.</p>

<p><sup class="versenum">42&nbsp;</sup>The soldiers planned to kill the prisoners to prevent any of them from swimming away and escaping.<sup class="versenum">43&nbsp;</sup>But the centurion wanted to spare Paul&rsquo;s life and kept them from carrying out their plan. He ordered those who could swim to jump overboard first and get to land.<sup class="versenum">44&nbsp;</sup>The rest were to get there on planks or on other pieces of the ship. In this way everyone reached land safely.</p>
<!-- end bible -->

<p class="bible"></p>
</div>


<button id="MC2/eng/video/multiply3/352.mp4" type="button" class="external-movie">
         Watch &nbsp;"Acts 27:27-44"&nbsp;</button>
    <div class="collapsed"></div>

<p class="up">Discovery Discussion (Everyone answers)</p>

<ul class="up">
	<li>What caught your attention or what did you like best? Why?</li>
	<li>What is new or has developed at this point in the story?</li>
	<li>What is being modeled about a Spirit-dependent life, making disciples or leadership?</li>
	<li>How can we live differently now that we know this story?</li>
</ul>

<p><em>Additional questions you can use:</em></p>

<ul>
	<li>How are Jesus&rsquo; followers continuing His work of making disciples and church planting?</li>
	<li>How is the gospel impacting people and society?</li>
	<li>What barriers or obstacles were overcome and how were they overcome?</li>
</ul>

<!-- begin note sdcard -->
<div class="note-div">
    <form class="auto_submit_item">
      <textarea
        class="textarea resize-ta"
        @keyup="this.addNotes()"
        id="note1Text"
      ></textarea>
    </form>
</div>
<!-- end note sdcard -->


<h2 class="up">Read, Tell and Correct</h2>

<ul class="up">
	<li>Read the story again. Have someone tell the story and ask the group to correct if necessary.</li>
</ul>

<!-- begin default revealSummary -->
<div id="Summary2" class="summary"><h2 class="up">+ Summary</h2></div>
<div class="collapsed" id ="Text2">
<!-- end default revealSummary -->
<p class="up">The storm lasted over two exhausting and terrifying weeks! Paul insisted that the soldiers had to all to stay together in order for them to survive. They faced incredible danger, but Jesus was faithful to His promise and no one was harmed. Paul modeled trust in the faithfulness and goodness of God to all the non-believers and they were encouraged. This is a great example of valuing, praying for, and caring for all people regardless of their religion, race or position, just like Jesus did. The guards feared they would escape and wanted to execute all the prisoners but once again God worked through the favor of a Centurion to protect Paul.</p>

</div>

<p class="up"><em>Practice giving and communion here or in the Preparing for Mission section</em></p>

<div class="lesson"><img class="lesson-icon" src="@/assets/images/standard/look-forward.png" />
<div class="lesson-subtitle"><span class="forward">LOOKING FORWARD</span></div>
</div>

<!-- begin default revealSummary -->
<div id="Summary3" class="summary">
<div class="page_content ltr">
<div class="block ltr">
                        <div class="chapter_number ltr"><h1>52.</h1></div>
                        <div class="chapter_title ltr"><h1>Jesus' Faithfulness to His Promise</h1></div>
                    </div>
<div id="showVideoOptions"></div>


  <div class="lesson"><img class="lesson-icon" src="@/assets/images/standard/look-back.png" />
<div class="lesson-subtitle">+ <span class="back">LOOKING BACK</span></div>
</div>

<!-- begin default revealSummary -->
<div id="Summary0" class="summary"><h2 class="back">+ Praise</h2></div>
<div class="collapsed" id ="Text0">
<!-- end default revealSummary -->
<p class="back"><em>Read a scripture<div class="lesson-subtitle"><span class="back">LOOKING BACK</span></div>
</div>

<!-- begin default revealSummary -->
<div id="Summary0" class="summary"><h2 class="back">+ Praise</h2></div>
<div class="collapsed" id ="Text0">
<!-- end default revealSummary -->
<p class="back"><em>Read a scripture and sing worship songs.</em></p></div>
<div class="collapsed" id ="Text3">
<!-- end default revealSummary --><div class="reveal">&nbsp;

<h2 class="forward">Preparing for Mission</h2>

<ul class="forward">
	<li>Practice needed skills or previous topics to help prepare to minister to others:<br />
	o Prayer, Care, Share<br />
	o Gospel<br />
	o Foundational Bible Studies.</li>
</ul>

</div>

<h2 class="forward">Going on the Mission&nbsp;</h2>

<ul class="forward">
	<li>Identify people or places you will take the initiative to minister to this week.</li>
	<li>Write &ldquo;I will by when&rdquo; statements and share with your small group.</li>
</ul>

<!-- begin note sdcard -->
<div class="note-div">
    <form class="auto_submit_item">
      <textarea
        class="textarea resize-ta"
        @keyup="this.addNotes()"
        id="note2Text"
      ></textarea>
    </form>
</div>
<!-- end note sdcard -->


<h2 class="forward">Praying For the Mission</h2>

<ul class="forward">
	<li>Commit everyone&#39;s goals to the Lord. Ask the Lord to help us be faithful and use us to start a movement of disciple-makers.</li>
</ul>

<h2>Benediction (optional)</h2>



</div><!--- Created by publishPage-->
</div>
  <Footer/>
</template>
